**Installing and using the "Jone Soft Generic Mod Enabler" (JSGME).**

Installing the Mod Enabler.

1. There will be four files in this download: JoneSoft_Release_Notes.txt, JoneSoft_User_Guide.pdf, JSGME.exe, and JSGME.ini.

2. Copy and paste the JSGME.exe, and JSGME.ini files into your game's main folder - that is, the folder where the game's .exe is 
   located that launches the game. You can copy and paste these two files into as many game folders as you want to use the mod enabler 
   in - such as, SMG, SMA, WNLB, and ANGV.

3. In the game's main folder, double click on the JSGME.exe. The Mod enabler screen should pop up. Next close the screen by clicking the closed 
   bottom at the bottom of the screen. That is it...the Mod Enabler is installed.

Using the Mod Enabler.

1. After you have installed the Mod Enabler, you will now see a newly created folder called MODS in your main game folder.

2. Open the MODS folder, and copy and paste any game mod or battle pack folder that you want to play. Copy the whole folder, not 
   it's individual contents. You can put as many mods into the MODS folder as you want. As a suggestion, start out with only one mod at first 
   until you understand how the Mod Enabler works.

3. Go back to the game's main folder, and double click on the JSGME.exe again. The Mod Enabler Screen will pop up, but this time the 
   mods that you just copied and pasted into the MODS folder should appear on the left hand side of the screen. 

4. Single click on the mod that you want to enable to highlight it. The top button in the middle of the screen will highlighted (>). Click on it, and 
   your mod will now appear on the right hand side of the screen. The mod is now enabled to play. Next, close the Mod Enabler at the bottom 
   of the screen. (Note: If you are enabling or disabling a very large mod, watch the green loading bar in the lower right hand corner of the 
   screen to make sure the process is completed before you close the screen). That's' it! Play the mod.

5. To disable a mod, double click on the JSGME.exe. When the screen pops up, click on the mod that you want to disable to highlight it. Next 
   press the second button (<), and the mod will move to the left and be disabled. Now close the screen.

6. VERY IMPORTANT! Only enable one mod at a time. Unable the mode you are playing, before you enable another one. If you want to remove any 
   mod from the MODS folder, just delete it.

------------------------------------------------------------------------------------------------------------------------------------------------------   
*Tips for Using the JSGME Mod Enabler.

- You can load any "folder" into the MODS folder, but not the individual contents of a game. For example, if you want to play a series of Scenarios 
  created for SMG or SMA, do not copy and paste the individual Scenarios directly into the MODS folder. Instead, create a new folder named 
  whatever (SMG Scenarios or SMA Scenarios for example), and place the Scenarios into that folder first, and then copy and paste the new folder into 
  the MODS folder for the Scenarios to be enabled. As another example, if you want to play a user created Battle Pack of a particular battle, just 
  copy the entire game folder into the MODS folder. Do not copy the individual contents of the Battle Pack's folder into the MODS folder, but copy 
  the Battle Pack's folder with the contents already in it to the MODS folder. 

_ The JSGME Mod Enabler will also enable files from a sub folder. The SMFiles Utility previously used to load game files will not do this. In the 
  games SMG and SMA, there is only one sub folder called "Sounds". Sometimes you will come across a Battle Pack that will have new sounds included 
  in the Pack. For example, when you look into a Packs game folder, you might see a sub folder called "xxx Sounds" ("Waterloo Sounds" for example). 
  Just rename the folder to Sounds, and leave it in the Pack's main game folder.  The JSGME Mod Enabler will now load the new sounds along with the 
  rest of the Pack's files , and will automatically place the new sounds into the SMG's or SMA's main Sound folder for you. 

  *Note: As time allows, the Pack downloads from antietam-gettysburg.com will have this renaming of the Sounds folder already done for you. If you have 
   downloaded a Pack previously from another site, or earlier from this site, you may have to make this adjustment yourself.


*The JSGME mod enabler should be used to replace of the SMFiles Utility that was previously used to load user created mods. Here are some of the 
 improvements of using the JSGME mod enabler verses the SMFiles Utility:

- The JSGME mod enabler should work properly on Windows 7 without any further adjustments...unlike the SMFiles Utility which needed special 
  adjustments to work properly. 

- As mentioned above, the JSGME mod enabler will load the contents of a sub folder...the SMFiles Utility will not do this unless it is used to replace 
  the entire folder. 

- You can put a significantly larger number of mods into the JSGME MODS folder without running into error problems...unlike the SMFiles Utility
  which recommended not loading too many mod folder into it.

- The JSGME mod enabler loads and unloads faster.

- Read more about the JSGME mod enabler in the included papers in the download.








